#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_
#include "term.h"
#include "basiclist.h"


typedef struct{
node_t * sptr;
}poly_t;


#endif 
