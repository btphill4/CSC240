#include <stdio.h>
#include <stdlib.h>
#include"polynomial.h"
#include "basiclist.c"
#include "term.c"

char * cptr;
poly_t * head;
 

poly_t * new_polynomial() 
{
poly_t * head  = null;
head = malloc(sizeof(poly_t));
return head;
}

void add_to_polynomial(poly_t * poly, const term_t * term)
{
list_add(head, &term);
}

void print_polynomial(const poly_t * poly)
{
term_to_string(&poly);
}

void * delete_polynomial(poly_t ** poly)
{
free(head);
}


/*
poly_t * combine_like_terms(const poly_t * poly)
{

return 0;
}
*/




