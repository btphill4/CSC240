#include<iostream>
#include<vector>
#include<algorithm>
#include "term.hpp"


using namespace std;

class Polynomial{
private: 
vector<Term> poly;


public:
Polynomial(){
}

void add(Term t)
{
poly.push_back(t);
}

void print()
{
/*
for(Term i = poly.begin(); i != poly.end(); i++)
{
    std::ostream  << i << endl;
}
*/
/*
for (int ii = 0; i < poly.size(); ii++)
	{
		cout << p.coef.at(i) << "x^" << p.expon.at(i);
		if (i != p.totall() - 1)
			cout << "+";
	}
*/

for(Term ii: poly) 
{
	std::cout << ii.toString()  << " ";
}

}



ostream operator<<(ostream& o, const Polynomial& poly) {
  for (int ii = 0; i < poly.size(); i++){
	if(ii) {
		o << " + ";
		  }
	o << poly[ii];
	}
	return 0;
}
/*
Polynomial combineLikeTerms()
{
Polynomial newPoly;		//create new vector
auto i = begin(poly);	//reads through the vector
newPoly.add(i);		//adds objects to vector

//incomplete


}
*/

};






